//id,iconName,iconUrl,url,width,height
var shortcut = [
[0,"腾讯微博","images/icos/wb.png","http://show.v.t.qq.com/index.php?c=show&a=index&n=bzyxytxwb&w=800&h=500&fl=2&l=12&o=31&co=0",800,500],
[1,"人人网","images/icos/renren.jpg","http://page.renren.com/",1000,500],
[2,"微信公众平台","images/icos/wx.jpg","https://mp.weixin.qq.com/cgi-bin/message?t=message/list&count=20&day=7&token=188810364&lang=zh_CN",800,500],
[3,"QQ轻聊","images/icos/qq.jpg","http://w.qq.com/",800,500],
[4,"我的E梦园","images/icos/emy.png","htm/emy.htm",800,500],
];